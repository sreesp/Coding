class Launch 
{
	public static void main(String args[])
	{
		System.out.println("Hello");
	}
}

//To Compile
		//javac <FileName> 

//To Execute
		//java <ClassName>