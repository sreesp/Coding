
//program to count number of objects created

class Check {
	
	int a;
	int b;
	
	int count;
	
	
	{
		count++;
	}
	
}

class StaticCheck {
	
	int a;
	int b;
	
	static int count;
	
	//if anything get executed during every object creation we keep that something inside java block
	{
		count++; 
		//count should be place inside a java block because, java block will get executed every time of object creation
		//behind the scene, java block will be included at the starting of every constructor of class irrespective of parameter 
	}
	
}

public class Launch03StaticVariable {

	public static void main(String[] args) {
		
		Check c1 = new Check(); //count = 1
		Check c2 = new Check(); //count = 1
		Check c3 = new Check(); //count = 1
		Check c4 = new Check(); //count = 1
		
		//for every object creation count value is 1 only
		//it is because for every object creation a new memory for count is been given inside each object on  heap
		
		//if we make count as static, memory will be given only once, so for every object same copy will get used
		//So, how many objects get created, that many times count value will increased by 1
		//Therefore, number of objects = count value

		StaticCheck sc1 = new StaticCheck();
		StaticCheck sc2 = new StaticCheck();
		StaticCheck sc3 = new StaticCheck();
		StaticCheck sc4 = new StaticCheck();
		System.out.println("No. of objects get created: " + StaticCheck.count);
		//static variables are known as class variables (memory will get created only once in a class)
	}

}
