
public class Launch01Static01 {

	public static void main(String[] args) {
		
		Demo.display();
		Demo d = new Demo();
		d.disp();  
		//run the code and notice the order of execution

	}

}

class Demo {
	
	//static variable
	static int a;
	static int b;
	
	//static block
	static {
		System.out.println("static block");
		a = 10;
		b = 20;
		System.out.println();
	}	
	
	//static method
	static void display() {
		System.out.println("static method");
		System.out.println("a: " + a);
		System.out.println("b: " + b);
		System.out.println();
	}
	
	//instance variable
	int x;
	int y;
	
	//java block
	{
		System.out.println("Non static java block");
		x = 16;
		y = 22;
		System.out.println();
	}
	
	//non static method
	void disp()
	{
		System.out.println("non static method");
		System.out.println("x:" + x);
		System.out.println("y:" + y);
		System.out.println();
		
	}
	
	//Constructor
	Demo()
	{
		System.out.println("Constructor");
		System.out.println();
	}
	
}
