public class Launch02StaticControllFlow {
	
	//static variable
		static int a;
		static int b;
		
		
		//static block
		static {
			System.out.println("static block");		
			b = 20;
			System.out.println();
		}
		
		//static method
		static void display() {
			System.out.println("static method");
			System.out.println("a: " + a);
			System.out.println("b: " + b);
			System.out.println();
		}
		
		//instance variable
		int x;
		int y;
		
		//java block
		{
			System.out.println("Non static java block");
			x = 16;
			y = 22;
			System.out.println();
		}
		
		//non static method
		void disp()
		{
			System.out.println("non static method");
			System.out.println("x:" + x);
			System.out.println("y:" + y);
			System.out.println();
			
		}
		
		//Constructor
		Launch02StaticControllFlow()
		{
			System.out.println("Constructor");
			System.out.println();
		}
	
	public static void main(String[] args) {
		Launch02StaticControllFlow.display(); //static method can be called using ClassName
		Launch02StaticControllFlow obj = new Launch02StaticControllFlow();
		obj.disp();
		Launch02StaticControllFlow.b = 200; //static variable can be called using ClassName
		obj.display(); //static method can also be called using object reference
		obj.b = 100; //static variable can also be called using object reference
		a = 140; ////static method can also be called directly if it is present in same class
		display(); //static method can also be called directly if it is present in same class
	}
	
}
