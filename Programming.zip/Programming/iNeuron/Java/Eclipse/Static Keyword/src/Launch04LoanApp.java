import java.util.Scanner;

class Farmer {
	
	private float pa;
	private float td;
	private float si;
	private static float ri; //rate of interest is common to all farmer object. so, we can make it as static variable
	
	static {
		ri = 6.5f; //it is good practice to assign a value to static variable in static block 
	}
	
	void input() 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Kindly ente3r loan principle amout");
		this.pa = sc.nextFloat();
		System.out.println("Kindly mention time duration");
		this.td = sc.nextFloat();
	}
	
	void calculateSI() {
		this.si = (this.pa*this.td*this.ri)/100;
	}
	
	void display() {
		System.out.println("Simple Interest will be: " + this.si);
	}
	
}


public class Launch04LoanApp {

	public static void main(String[] args) {
		
		
		Farmer f1 = new Farmer();
		f1.input();
		f1.calculateSI();
		f1.display();
		
		Farmer f2 = new Farmer();
		f2.input();
		f2.calculateSI();
		f2.display();
		
	}

}

