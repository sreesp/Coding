

class Calculator01 
{
	//HAS Part
	int a, b, c; //instance variables
	
	//DOES Part
	void add() 
	{
		//here we are doing addition which is a task/activity, so we are doing it in method
		a = 10;
		b = 20;
		int a = 40;
		c = a+b;	
		System.out.println(c);
	}
}


public class Launch01Calculator 
{
	public static void main(String[] args) 
	{
		
		Calculator01 calc = new Calculator01(); //object creation. Calculator01 class got life by creating onject
		
		calc.add();
		System.out.println(calc.a);
         
	}
}
