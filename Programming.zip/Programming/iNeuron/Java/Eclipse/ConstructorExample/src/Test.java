
class Employee
{
	private String name;
	private int id;
	private String role;
	private int salary;
	private String location;
	
	Employee(int id, String name, String role)
	{
		this(role);
		this.id = id;
		this.name = name;
	}
	Employee(String role)
	{
		this(60000);
		this.role = role;
	}
	
	Employee(int salary) 
	{
		this();
		this.salary = salary;
	}
	Employee()
	{
		location = "Bangalore";
	}
	
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public String getRole() {
		return role;
	}
	public int getSalary() {
		return salary;
	}
	public String getLocation() {
		return location;
	}
	
	
	
}


public class Test {

	public static void main(String[] args) {
		
		Employee emp = new Employee(1002, "Pranav", "java developer");
		System.out.println("Employee details :: " + "\n"
							+ "Name: " + emp.getName() + "\n"
							+ "Location: " + emp.getLocation() + "\n"
							+ "Salary: " + emp.getSalary());

	}
	

}
