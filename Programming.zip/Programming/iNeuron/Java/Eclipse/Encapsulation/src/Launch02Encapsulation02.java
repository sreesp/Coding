//This class can be called as 'Bean' as all the instance variable are private
class Dog
{
	private String name;
	private int cost;
	
	public void setName(String name) {
		this.name = name;
		//'this' is a such a keyword which holds current running object reference
	}
	public String getName() {
		return name;
	}
	
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getCost() {
		return cost;
	}
	
}



public class Launch02Encapsulation02 {

	public static void main(String[] args) {
		
		Dog d1 = new Dog();
		d1.setName("Saakhi");
		d1.setCost(36000);
		System.out.print("The name of the dog d1 is " + d1.getName() + " and its cost is " + d1.getCost());
		
	}

}
