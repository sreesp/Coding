
class Employeeee
{
	private String name;
	private int eid;
	private String location;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	//We can have a common setter for all datamembers/properties
	public void setData(String name, int eid, String location) {
		this.eid = eid;
		this.location = location;
		this.name = name;
	}
	
	//we cannot have common getter because return statement can return only one value
	
	//instead of common setter we have a specialized method whose name will be same that of the class name with no explicit return type, such a method called as Constructor
	public Employeeee(String name, int eid, String location) {
		this.eid = eid;
		this.location = location;
		this.name = name;
	}
	
}

public class Launch04Encapsulation04Constructor01 {

	public static void main(String[] args) {
		
		//Employeeee emp = new Employeeee(); //it is also a call to constructor
		//using separate setters
//		emp.setName("Vishnu");
//		emp.setEid(1001); 
//		emp.setLocation("Kakinada"); 
		
		//.Constructor is invoked/called automatically we create the object. (at the time of object creation)
		Employeeee emp2 = new Employeeee("Pranav", 1002, "Bengaluru");
		//Note: Whenever we want something to get executed at the the of instantiation(object creation), in that case, keep that particular thing inside the constructor because constructor is getting executed at the time of object creation.
		//Creation of object involves call to a Constructor
		
	}

}
