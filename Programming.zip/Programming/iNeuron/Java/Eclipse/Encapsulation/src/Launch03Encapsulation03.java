
class Employeee 
{
	private String name;
	private int eid;
	private String location;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	//We can have a common setter for all datamembers/properties
	public void setData(String name, int eid, String location) {
		this.eid = eid;
		this.location = location;
		this.name = name;
	}
	
	//we cannot have common getter because return statement can return only one value 
	
}

public class Launch03Encapsulation03 {

	public static void main(String[] args) {
		
		Employeee emp = new Employeee();
		//using separate setters
		emp.setName("Vishnu");
		emp.setEid(1001); 
		emp.setLocation("Kakinada"); 
		
		
		Employeee emp2 = new Employeee();
		emp2.setData("Pranav", 1002, "Bangalore"); //using common setter
		
	}

}
