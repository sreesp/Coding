
//Constructor Overloading: Having multiple constructors in a class with different parameters

class Studenttt
{
	private String sname;
	private int sid;
	private String scity;
	
	public Studenttt(int sid, String sname, String scity)
	{
		this.sname = sname;
		this.scity = scity;
		this.sid = sid;
	}
	
	//As we already included one constructor, JVM will not create any other constructor. Whatever constructors we want we should create those constructors,
	
	public Studenttt() 
	{
		sname = "Vishnu";
		sid = 1002;
	}
	
	public Studenttt(String sname, String scity)
	{
		this.sname = sname;
		this.scity = scity;
	}
	
	

	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	
	public String getScity() {
		return scity;
	}
	public void setScity(String scity) {
		this.scity = scity;
	}
	
	
	
	
}

public class Launch05Encapsulation06Constructor03 {

	public static void main(String[] args) {
		
		Studenttt std1 = new Studenttt(); //calling non parameterized constructor  
		System.out.println("Student 1 details ::");
		System.out.println("Name: " + std1.getSname() + "\n" 
						+ "Id: " + std1.getSid() + "\n" 
						+ "City: " + std1.getScity());
		
		System.out.println();
		
		Studenttt std2= new Studenttt(1002, "Pranav", "Bangalore"); 
		System.out.println("Student 2 details ::");
		System.out.println("Name: " + std2.getSname() + "\n" 
						+ "Id: " + std2.getSid() + "\n" 
						+ "City: " + std2.getScity());
		
		System.out.println();
		
		std1.setScity("Kakinada");
		System.out.println("Student 1 details ::");
		System.out.println("Name: " + std1.getSname() + "\n" 
						+ "Id: " + std1.getSid() + "\n" 
						+ "City: " + std1.getScity());
		
	}

}
