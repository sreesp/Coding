
class Employee 
{
	//instance variable, data members, fields, properties
	int eid;
	String ename;
	String location;
	
	//these data members(properties of this class) can be accessed directly within the class
			//Data members are directly getting accessed outside the class (in another class) (by object reference), this is got good, this is never accepted, this is not good programming style
			//This is happening because there is no security for those data members 
			//We should provide restriction to those data members by saying direct should be there only within the class and direct access should not be there out side the class
	
}

//A class which has all data members as private, such class called as Bean
class Student 
{
	
	//Requirement - 1 (creating variables)
	//By using 'private' keyword we can provide security/restriction to data members. 
	//By saying private in same class we can access directly, but in other classes we cannot access these properties
	//We are hiding data of properties/ data members of particular class by using 'private' keyword. So Encapsulation is known as Data Hiding
	private int age;
	private String name;
	private String city;
	private boolean married;
	
	
	
	
	
	//Requirement-2 (Getting data from outside the class and giving/keeping/setting that data to variable)
	//as we make variables private, data cannot be given directly from outside the class. We need to make some arrangements
	
	//Activity --> from outside taking that data and give to our variable
	//For this activity we use method concept (setting method)
	
	//If a method is doing a activity of receiving data from outside and setting it to its data member, such a method is called as 'setter'
	//The sole purpose of this method is to receive data from outside and set it to its data members, so it should have parameters to accept input(data via argument)  and it should not return anything, so return type should be void
	void setAge(int a)
	{
		age = a;
	}
	
	
	//using data of the data member outside the class
	
	
	//If a method is doing a activity of getting data from its data members and returning it(data) to outside class, such a method is called as 'getter'.
	//The purpose of this particular method is to return data to whoever wants
	//Getter must not accept any input.
	int getAge()
	{
		return age;
	}
	
	//Data Binding: for every private variable, we have a methods(getter/setter). The variable and method are binded to work together (age variable is binded to getAge and setAge method)
	
	
	//it is good practice give the name to parameter as the variable name for setters to not get confused while setting the data in another class by a a programmer
	void setCity(String city) 
	{
		city  = city; 
		//shadowing problem: whenever there is name conflict between instance variable and local variable within a setter then JVM will not allocate value to instance variable as it treat both as local variable
		//To avoid shadowing problem, we have a keyword called 'this'
		this.city /*instance variable*/ = city /*local variable*/;
	}
	
	void setName(String name) {
		this.name = name; //Instantiating local variable value to instance variable
	}
	
	//If the return type is boolean, the for getters it is highly recommended to use method name as (is+propertyName) like isMarried() instead of getMarried()
//	boolean getMarried() {
//		return married;
//	}
	public boolean isMarried() {
		return married;
	}
	
	//Setters and getters should be enabled to entire project , so it is always recommended to use setters and getters with 'public' access specifier
	
}
public class Launch01Encapsulation01 
{

	public static void main(String[] args)
	{
		
		
		Employee emp = new Employee();
		//Data members are directly getting accessed outside the class (in another class) (by object reference), this is got good, this is never accepted, this is not good programming style
		//This is happening because there is no security for those data members 
		//We should provide restriction to those data members by saying direct should be there only within the class and direct access should not be there out side the class
		emp.ename = "Vishnu";
		emp.eid = 1001;
		emp.location = "Kakinada";
		
		Student std = new Student();
		//The data members cannot be accessed directly here, but they somewhat accessed indirectly by a control
		//So, we can say, Encapsulation refers to providing controlled accessed to data member of particular class in another class through getters and setters by avoiding/preventing direct access.
		std.setAge(10); //setting data to age
		int studentAge = std.getAge(); //getting data from age
		System.out.println(studentAge);
	}

}


