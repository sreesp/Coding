
class Studentt
{
	private String name;
	private int age;
	private String city;
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getCity() {
		return city;
	}
	public Studentt(String name, int age, String city) {
		super();
		this.name = name;
		this.age = age;
		this.city = city;
	}
	public Studentt() {
		
	}
	
	//Constructor Overloading: Having multiple constructors in a class with different parameters
	
	

}

public class Launch05Encapsulation05Constructor02 {

	public static void main(String[] args) {
		
		Studentt std = new Studentt(); //calling 'Studentt()' constructor of zero parameters which is not defined in Studentt class, eventhough it is not throwing error
		//Whenever there is call to a constructor and as a programer  in that particular class if we not specified any constructor, then jvm automatically will  include a default constructor of zero parameters.
		//If we are calling parameterized constructor, jvm will not incude it. Programmer should include it. 
		
		//Whenever there is call to constructor and programmer has not specified any constructor that time JVM will include a constructor which is of zero parameterized.
		//if programmer has specified any one constructor in program irrespective of parameterized or non parameterized in that case JVm will not include any constructor.   
		//Once we created a parameterized constructor, and we want to call non parameterized constructor, it will not be included by JVM. It should be specified by programmer
		
		
	}

}
