
//Method Overloading:
//The process of writing multiple(more than 1) method with same name and different parameter within a class is called MethodOverloading

class Calculator
{
	int add(int a, int b)
	{
		return a+b;
	}
	
	int add(int a, int b, int c)
	{
		return a + b+ c;
	}
	
	float add(int a, float b)
	{
		return a+b;
	}	
	
	float add(float a, float b)
	{
		return a + b;
	}
	
	float add(int a, float b, float c)
	{
		return a + b+ c;
	}
	
	double add(int a, int b, double c) 
	{
		return a + b+ c;
	}
}


public class Launch01 {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		int a = 10, b = 20, c = 30;
		float m = 10.5f, n = 20.5f, o = 30.5f;
		double x = 15.5, y = 25.5, z = 35.5;
		
		System.out.println(calc.add(a, b));
		System.out.println(calc.add(m, n));
		System.out.println(calc.add(a, b, x));
		
		//Method Overloading - Developer thinks 1 method is overloaded with multiple tasks but the reality is 1 method is performing only 1 task.

		String s1 = "java";
		String s3 = "jsva";
		String s2 = s1.toLowerCase();
		String s4 = s1.replace('a', 'a');
		
		System.out.println(s1.equals(s4));
		System.out.println(s1==s2);
		System.out.println(s2==s4);
		System.out.println(s1==s4);
		
		
		int i = 1;
		for(System.out.println(10);i<3;System.out.println("Hi")) {
			System.out.println("loop");
			i++;
		}
		String s = new String(" Salapaka");
		StringBuffer sb = new StringBuffer("Pranav");
		sb.append(s);
		System.out.println(sb);
		sb.append("vishnu", 2, 5);
		System.out.println(sb);
		
		String ss1 = new String("Vishnu");
		String ss2 = "Vishnu";
		String ss3 = ss1;
		String ss4 = ss2;
		System.out.println(ss1==ss4);
		System.out.println(ss4==ss2);
		System.out.println("A".charAt(0)=='A');
		
		
		
	}

}
