
class Parentt 
{
	//Constructor
	Parentt()
	{
		System.out.println("Super class Constructor");
	}

}

class Childd extends Parentt
{
	Childd(int i) {
		//super(); //by default included by compiler
		System.out.println(i);
	}
}

public class Launch03 
{
	public static void main(String[] args)
	{
		Childd s = new Childd(8); //Constructor of parent class will be called due to super() method present.
		
	}
}
