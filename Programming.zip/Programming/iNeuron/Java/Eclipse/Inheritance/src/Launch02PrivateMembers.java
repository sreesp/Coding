
class Parent 
{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}


class Child extends Parent
{
	void declare()
	{
		//name = "Pranav"; //as name is private in Parent class it does not get inherited
	}
}


public class Launch02PrivateMembers {

	public static void main(String[] args) {
		
		Child c = new Child();
		c.setName("Vishnu"); //we can access setters and getters
		System.out.println(c.getName());

	}

}
