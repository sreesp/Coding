
class Demo1 
{
	String name = "Pranav";
	int age = 19;
	
	void display() 
	{
		System.out.println("Demo 1: " + name + " " + age);
	}
}

class Demo2 extends Demo1 
{
	
}

public class Launch01 
{

	public static void main(String[] args) 
	{
		
		Demo2 d = new Demo2();
		d.display();

	}

}
