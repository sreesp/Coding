/*

Truncate : Delete content of Table
		   Rollback is not possible
           
   VS
           
Delete : Delete content of Table
		   Rollback is possible

*/

insert into student (id, age, fname, lname, grade, country, city, state) 
values(1004, 17, 'Dheeraj', 'P', 12, 'India', 'Hyderabad', 'Telangana'),
(1005, 17, 'Sahithi', 'A', 12, 'India', 'Vizag', 'Andhra Pradesh');

select * from student;

set autocommit = 0;

delete from student where id = 1004;
select * from student;
rollback; -- deleted data will be retrieved
select * from student; 


insert into newEmployees values(1002, 'Sreepranav', 'Salapaka', 60000), (1003, 'Sahithi', 'Adhiraju', 40000);
select * from newEmployees; 
commit;
delete from newEmployees;
select * from newEmployees;
rollback;
select * from newEmployees;

truncate table newEmployees; -- truncate delete entire data which can't be retrieved
select * from newEmployees;
rollback;
select * from newEmployees;