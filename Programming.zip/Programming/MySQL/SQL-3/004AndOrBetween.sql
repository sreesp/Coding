select * from student;


select * from student where age >= 9 and age<11;
select * from student where age > 9 and age<11;

select * from student where age = 9 or age = 11;

select * from student where age>=9 or age<=11;
select * from student where age>=9 and age<=11;

select * from student where age between 9 and 11;
