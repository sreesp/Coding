
/*

Foreign

In a table we can have column with Foreign key
Foriegn key in one table will be primary key in another table
One table can have many foreign keys

*/


/* 

Primary Key : Unique column ( Multiple Columns not allowed)
			  No null value
              Unique Value
              Only 1 in a table
              
Unique Key : Unique Values
			 Null values allowed
             Multiple Columns allowed
             
Foriegn Key : Multiple Columns allowed
			  No Null Values
              Same value allowed
              Foreign key in one table is Primary key in another column

*/










