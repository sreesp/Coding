-- Inner Join
-- Left Join
-- Right Join
-- Cross Join

create table courses(
cid int(3) auto_increment primary key,
cname varchar(10));

create table std (
id int(4) auto_increment primary key,
name varchar(20) not null,
age int(3) not null,
course int(3),
foreign key(course) references courses(cid)
);



insert into courses value(101, 'HTML');

insert into courses (cname) value ('Java'), ('SQL'), ('JS'), ('Python'), ('C#'), ('CSS'), ('C'), ('C++');

select * from courses;


insert into std value
(1001, 'Sreevishnu', 10, 101);

insert into std (name,age, course) values
('Sreepranav', 19, 102),
('Ganesh', 21, 104),
('Dheeraj', 17, 103),
('Praneeth',18, 107),
('Sathvik', 20, 101),
('Sahithi', 20, 102),
('Raja Pavan', 20, 109),
('Raghu Charan', 9, 102),
('Vineeth', 10, 101),
('Archana', 20, 104),
('Surabhi', 20, 109),
('Kishore', 20, 109),
('Vamshi', 19, 105);

select * from std;

select * from std inner join courses on std.course = courses.cid;

select id, name, cname from std s inner join courses c on s.course = c.cid order by id;

select id, name, cname from std s inner join courses c on s.course = c.cid where cname= 'Java' order by id;




