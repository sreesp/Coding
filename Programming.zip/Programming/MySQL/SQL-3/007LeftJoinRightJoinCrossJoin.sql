drop table std2;

create table std2 (
id int(4) auto_increment primary key,
name varchar(20) not null,
age int(3) not null,
course int(3)
);

insert into std2 value
(1001, 'Sreevishnu', 10, 101);

insert into std2 (name,age, course) values
('Sreepranav', 19, 102),
('Ganesh', 21, 104),
('Dheeraj', 17, 103),
('Praneeth',18, 107),
('Sathvik', 20, 101),
('Sahithi', 20, 102),
('Raja Pavan', 20, 109),
('Raghu Charan', 9, 102),
('Vineeth', 10, 101),
('Archana', 20, 104),
('Surabhi', 20, 116),
('Kishore', 20, 122),
('Vamshi', 19, 105);

select * from std2;

/*

Right Join: Maching Data/Record + All the Records of Right Table

*/

select * from std2 right join courses on std2.course = courses.cid;
select id, name, cname from std2 s right join courses c on s.course = c.cid;

/*

Left Join: Maching Data/Record + All the Records of Left Table

*/

select * from std2 left join courses on std2.course = courses.cid;
select id, name, cname from std2 s left join courses c on s.course = c.cid;

/*

Cross Join: Each data of left table will be joined with all the records of right table

*/

select * from std2 cross join courses;

