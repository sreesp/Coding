select  upper('Sreepranav'); 
select lower('SREEpranaV'); 

select * from student;

select upper(fname) from student; -- it will not impact in database, just for presentation purpose it covert for us to upper/lower...
select lower(fname) as Name from student;

select substr(country,1,3) from student;
select fname as Name, substring(lname, 1) as Initial, substring(country,1,3) as CountryCode from student;

select abs(-16); -- ignore -ve
select abs(22);
select pow(2,4); -- 2 power 4
