use ineuron ;

create table employees(eid int(6) auto_increment primary key, name varchar(20), location varchar(20), salary int (8));

insert into employees value
(1001, 'Sreevishnu', 'Kakinada', 86000);

insert into employees(name,location, salary) values
('Sreepranav', 'Bangalore', 84000),
('Ganesh', 'Kakinada', 72000),
('Dheeraj', 'Bangalore', 64000),
('Praneeth', 'Chennai', 64000),
('Sathvik', 'Bangalore', 72000),
('Vamshi', 'Hyderabad', 40000);

select * from employees;

update employees set location='Bangalore' where name='Sreevishnu';

select name, location, salary from employees order by location; -- by default asc order
select name, salary from employees order by salary desc;
select * from employees order by name asc;

select * from employees where salary>80000 and location='bangalore' order by salary asc;

select * from employees where salary<80000 and location!='bangalore' order by salary asc;

select * from employees where salary not between 60000 and 70000 and location='bangalore' order by salary asc;

select distinct location from employees;
select count(distinct location) from employees;