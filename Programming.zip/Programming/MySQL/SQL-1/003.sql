USE ineuron; -- using database 'ineuron' (tables will be created in the following database)

CREATE TABLE student(sid INT(6), sname VARCHAR(50));

DESC student;

DROP TABLE student;

CREATE TABLE ineuron.student(sid INT(5), sname VARCHAR(50)); -- creating TABLE in particular DATABASE