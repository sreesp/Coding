CREATE TABLE newStudents (
id int(4) AUTO_INCREMENT, -- 'auto increment' should be declared with a 'key'
fname varchar(20) not null,
lname varchar(20) NOT NULL,
age int (2) NOT NULL,
PRIMARY KEY(id) -- primary key can also be declared in this way
);

-- inserting multiple values at a time
INSERT INTO newStudents(fname, lname, age) VALUES ('Sreepranav', 'Salapaka' , 19), ('Sreevishnu' , 'Salapaka', 10);

SELECT * FROM newStudents;


/* next class

Primary Key: Cannot have Null Value
Unique Key: Can have Null values

*/