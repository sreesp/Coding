
/*
CRUD OPERATIONS

CRUD COMES INTO PICTURE AFTER CREATING DATABASE AND TABLE

C : INSERT STATEMENT (creating data)
R : SELECT STATEMENT (READING)
U : UPDATE STATEMENT
D : DELETE STATEMENT
*/

CREATE TABLE studentInfo(
id INT(4), -- columnName DATATYPE(LENGTH)
fname VARCHAR(20),
mname VARCHAR(20),
lname VARCHAR(20),
age INT(3),
city VARCHAR(20)
); -- semicolon is not mandatory in MySQL

DESC studentinfo;

INSERT INTO studentInfo VALUES(1, 'Uma Maheswara', 'Rao', 'Salapaka', 51, 'Peddapuram');
INSERT INTO studentInfo VALUES(2, 'Satya Sai Lalitha', 'Lakshmi', 'Salapaka', 46, 'Gangavaram');
INSERT INTO studentinfo(id, fname, mname, lname, age, city) VALUES(3, 'Sreevishnu', 'Karthikeya Hanuma', 'Salapaka', 10, 'Kakinada'); 
INSERT INTO studentinfo (id, fname, lname, age, city) VALUES (4, 'Sreepranav', 'Salapaka', 19, 'Kakinada');

SELECT * FROM studentinfo;










