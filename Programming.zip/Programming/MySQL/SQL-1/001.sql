SHOW DATABASES;

SHOW SCHEMAS;

-- database and schemas are same in MySQL
-- database and schemas are may different in other SQL languages