CREATE TABLE employee (
id int(4) not null,
fname varchar(20) not null,
mname varchar(20),
lname varchar(20) NOT NULL,
location varchar(20),
salary int (6) NOT NULL
);

DESC employee;

DROP TABLE EMPLOYEE;

CREATE TABLE employee (
id int(4) AUTO_INCREMENT  PRIMARY KEY, -- 'auto increment' should be declared with a 'key'
fname varchar(20) not null,
mname varchar(20),
lname varchar(20) NOT NULL,
location varchar(20),
salary int (6) NOT NULL
);

INSERT INTO EMPLOYEE VALUES(1001, 'Uma Maheswara', 'Rao', 'Salapaka', 'Aratlakatta', 80000);

SELECT * FROM employee;

INSERT INTO EMPLOYEE (fname, lname, location, salary) VALUES('Sreepranav', 'Salapaka', 'Chennai', 14000);

