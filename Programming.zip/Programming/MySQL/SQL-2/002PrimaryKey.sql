CREATE table student (
id int(6) primary key,
fname varchar(20) not null,
lname varchar(20) not null,
grade int(2) not null,
age int(2) not null,
city  varchar(20) not null,
state varchar(20) not null
);

insert into student (id, age, fname, lname, grade, city, state) values(1001, 10, 'Sreevishnu', 'Salapaka', 2, 'Kakinada', 'Andhra Pradesh');

select * from student;

insert into student (id, age, fname, lname, grade, city, state) 
values(1002, 11, 'Vineeth', 'V', 2, 'Kakinada', 'Andhra Pradesh'),
(1003, 9, 'Raghu Charan', 'O', 2, 'Kakinada', 'Andhra Pradesh');

select * from student;