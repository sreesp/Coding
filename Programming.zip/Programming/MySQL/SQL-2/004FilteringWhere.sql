use ineuron;

select * from student;

select fname, grade from student;

insert into student (id, age, fname, lname, grade, city, state) 
values(1004, 17, 'Dheeraj', 'P', 12, 'Hyderabad', 'Telangana'),
(1005, 17, 'Sahithi', 'A', 12, 'Vizag', 'Andhra Pradesh');

select * from student where grade=2;

select * from student where state='Telangana';

select fname, age from student where age<14;

select fname, id, grade, age from student where id>1002 and state = 'Andhra Pradesh';

select * from student where fname = 'SREEVISHNU'; -- CASE INSENSITIVE

select * from student where binary fname = 'SREEVISHNU'; -- CASE SENSITIVE : BINARY --> CHECK CASE ALSO

select id as studentId, fname as name, lname as surname from student; -- alias (getting column name as required)

