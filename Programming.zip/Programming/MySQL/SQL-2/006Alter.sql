ALTER TABLE student DROP COLUMN city;

select * from student;

alter table student add column city varchar(20) ;
desc student;

update student set city='KKD';

alter table student add column  country varchar(20) not null;
desc student;
select * from student;

update student set country='India';