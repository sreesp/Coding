delete from student where id = 1004;
select * from student;

select * from newStudents;
delete from newstudents; -- delete whole data in mentioned table
select * from newStudents;