/*

Primary Key : Unique Values, duplicates not allowed, Null not allowed, only one allowed in one table, 


*/

CREATE TABLE ineuron.newEmployees (
eid INT(4) PRIMARY KEY,
fname VARCHAR(20) NOT NULL,
lname VARCHAR(20) NOT NULL,
salary INT (8) 
);

desc ineuron.newemployees;

insert into newemployees values(1001, 'Sreevishnu', 'Salapaka', 80000);
insert into newemployees values(1001, 'Sreepranav', 'Salapaka', 80000); -- Error Code: 1062. Duplicate entry '1001' for key 'newemployees.PRIMARY'	(in primary key duplicates not allowed)
insert into newemployees(fname, lname, salary) values('Sreepranav', 'Salapaka', 80000);  -- Error Code: 1364. Field 'eid' doesn't have a default value (primary key should not be null)




