select * from student;

update student set lname = 'Adiraju' where id = 1005;
select * from student;

update student set grade = 5 where grade = 2;

update student set lname = 'S' where grade = 5 and age = 10;
select * from student;

update student set city = 'KKD' where state = 'Andhra Pradesh' or fname = 'Dheeraj';

update student set state = 'AP';
select * from student;