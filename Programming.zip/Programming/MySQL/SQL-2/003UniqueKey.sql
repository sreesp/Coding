/*

Unique Key : Have Unique Values, can be null

*/

CREATE table student2 (
id int(6) primary key,
fname varchar(20) not null,
lname varchar(20) not null,
grade int(2) not null,
age int(2) not null,
city  varchar(20) not null,
state varchar(20) not null,
accountNo int(4) unique key
);

insert into student2 (id, age, fname, lname, grade, city, state, accountNo) values(1001, 10, 'Sreevishnu', 'Salapaka', 5, 'Kakinada', 'Andhra Pradesh', 22);

select * from student2;

insert into student2 (id, age, fname, lname, grade, city, state) 
values(1002, 11, 'Vineeth', 'V', 2, 'Kakinada', 'Andhra Pradesh'); -- unique key can be null

insert into student2 (id, age, fname, lname, grade, city, state, accountNo) 
values(1003, 9, 'Raghu Charan', 'O', 2, 'Kakinada', 'Andhra Pradesh', 22); -- Error Code: 1062. Duplicate entry '22' for key 'student2.accountNo' (duplicates not allowed in unique key)
