import java.sql.*;
import java.util.*;

public class Insert3 {

	public static void main(String[] args) throws Exception {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/pwskills", "root", "root");
		Statement s = c.createStatement();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Player ID");
		int pid = sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Enter Player Name");
		String pname =sc.nextLine();
		
		System.out.println("Enter Team Name");
		String team = sc.nextLine();
		
		String query = String.format("insert into players values (%d, '%s', '%s');", pid, pname, team);       //format specifiers (%d for int and %s for String)
		
		int rowsEffected = s.executeUpdate(query);
		System.out.println(query);
		
		System.out.println("Rows effected: " + rowsEffected);
		
		sc.close();
		s.close();
		c.close();

	}

}
