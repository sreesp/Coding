package in.ineuron.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcUtil {
	
	//Creating private constructor to preveent creation of object of this class as all methods are static 
	private JdbcUtil() {
		
	}
	
	//Loading and Registering the Driver
	static {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		}
		
	}
	
	public static Connection getJdbcConnection() throws SQLException {
		
		String url = "jdbc:mysql://localhost:3306/pwskills", username = "root", password = "root";
		Connection connection = DriverManager.getConnection(url, username, password);
		
		return connection;
	}
	
	public static void cleanUp(Connection connection, Statement statement, ResultSet resultSet) throws SQLException {
		
		if (resultSet != null) {
			resultSet.close();
		}
		
		if (statement != null) {
			statement.close();
		}
		
		if (connection != null) {
			connection.close();
		}
				
	}

}
