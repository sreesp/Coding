package in.ineuron.main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import in.ineuron.util.JdbcUtil;

public class SelectApp {

	public static void main(String[] args) {
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try {
			
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null) 
				statement = connection.createStatement();
			
			if (statement != null) 
				resultSet = statement.executeQuery("select * from players;");
			
			if (resultSet != null) {
				System.out.printf("%-8s%-14s%s", "PID", "PNAME", "TEAM");
				System.out.println();
				
				while (resultSet.next()) {
					System.out.printf("%-8d%-14s%s", resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3));
					System.out.println();
				}
			}
			
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JdbcUtil.cleanUp(connection, statement, resultSet);
			} catch (SQLException e) {
				e.fillInStackTrace();
			}
		}

	}

}
