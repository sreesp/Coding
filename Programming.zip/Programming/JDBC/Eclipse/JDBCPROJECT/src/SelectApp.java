import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//Step 1: Load and Register the Driver
		//This is a optional step, as developer should remember external class name of particular SQL Vendor which is tight coupling
		//JVM will automatically find which SQL we using by url provided by us, and go to particular jar and finds Driver Class in META-INF.services folder
		//This feature came from JDBC V4.X
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Loading the Driver...");
		
		//Step 2: Establish the Connection
		String url = "jdbc:mysql://localhost:3306/pwskills"; //If Java program and database engine is running in same machine with default port no. for database the url can be "jdbc:mysql:///pwskills"
		String username = "root";
		String password = "root";
		Connection connection = DriverManager.getConnection(url, username, password);
		System.out.println("Connection Object created...");
		
		//Step 3: Create Statement Object and send Query
		
		Statement statement = connection.createStatement();
		System.out.println("Statement Object created...");
		
		//Step 4: Execute the Query and Process the resultSet
		String sqlQuery = "select pid,pname,team from players;";
		ResultSet resultSet = statement.executeQuery(sqlQuery);
		System.out.println("ResultSet Object created...");
		System.out.println();
		
		System.out.println("PID\tPNAME\tTEAM");
		while(resultSet.next()) {
			
			int pid = resultSet.getInt(1); //Retrieving result based on Column number
			String pname = resultSet.getString("pname"); //Retrieving result based on Column name
			String team = resultSet.getString(3);
			
			System.out.println(pid + "\t" + pname + "\t" + team);
			
		}
		
		//Step 6: Close the Resources
		
		resultSet.close();
		statement.close();
		connection.close();
		System.out.println("\nResources closed...");
		
	}

}
