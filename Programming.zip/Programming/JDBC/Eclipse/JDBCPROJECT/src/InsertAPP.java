import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertAPP {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver loading...");
		
		String url = "jdbc:mysql://localhost:3306/pwskills";
		String username = "root", password = "root";
		Connection connection = DriverManager.getConnection(url, username, password);
		System.out.println("Connection established...");
		
		
		Statement statement = connection.createStatement();
		System.out.println("Statement Object created");
		
		
		String insertQuery = "insert into players (`pname`, team) values ('Jadeja', 'CSK'),('Siraj', 'RCB'), ('Ali','CSK');";
		int rowsEffected = statement.executeUpdate(insertQuery);
		
		System.out.println("Inserted successfully...");
		System.out.println("Number of rows effected: " + rowsEffected);
		
		statement.close();
		connection.close();
		
	}

}
