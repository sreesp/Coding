import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/pwskills", "root", "root");
		
		Statement statement = connection.createStatement();
		
		int rowsEffected = statement.executeUpdate("update players set team = 'LSG' where pname = 'Rahul';");
		
		System.out.println("rows effected: " + rowsEffected + "\ndata updated successfully...");
		
		statement.close();
		connection.close();
		
	}

}
