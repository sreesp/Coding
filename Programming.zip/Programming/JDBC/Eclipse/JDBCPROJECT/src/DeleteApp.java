import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteApp {

	public static void main(String[] args) throws SQLException {
		
		Connection connection = DriverManager.getConnection("jdbc:mysql:///pwskills", "root", "root");
		
		Statement statement = connection.createStatement();
		
		int rowsEffected = statement.executeUpdate("delete from players where pname = 'Hardhik'");
		
		System.out.println("No. of rows effected: " + rowsEffected);

		statement.close();
		connection.close();
		
	}

}
