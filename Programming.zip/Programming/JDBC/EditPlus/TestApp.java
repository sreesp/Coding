import java.sql.*;

class TestApp 
{
	public static void main(String[] args) 
	{
		
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try
		{
			//Step 1: Load and register the Driver
			//We need to load and register the Driver as per the DB requirement (Oracle/MySQL)
			//As per teh DB specification, we need to set the JRE environment with the DB environment
			//Any class of DB vendor, we say it as DriverClass iff it has implemented a interface called "Driver".

			//MySQL ===> The implementation class of MySQL.jar is "Driver".
			Class.forName("com.mysql.cj.jdbc.Driver"); //Loading .class file explicitly into JRE 
			//Driver class is loaded, so in JRE JDBC environment for MySQL is setup.	
			System.out.println("Driver loaded successfully...");

			//Below code will get executed while loading Driver
			/*
			class Driver
			{
				static
				{
					Driver driver = new Driver();
					DriverManager.registerDriver(driver);
				}
			}
			*/

			//Step 2: Establish the Connection
			String username = "root";
			String password = "root";
			String dbProtocol_url = "jdbc:mysql://localhost:3306/pwskills";
			connection = DriverManager.getConnection(dbProtocol_url,username, password); //DriverManager is a utility class (contains only static entries/elements/members) in java.sql package
			System.out.println("The implementation class name is : " + connection.getClass().getName());
			System.out.println("Connection Established...");

			//Step 3: Creating Statement Object and send the Query
			String selectQuery = "SELECT * FROM players";
			statement = connection.createStatement();
			System.out.println("The implementation class name of Statement Interface is : " + statement.getClass().getName());
			resultSet = statement.executeQuery(selectQuery);
			System.out.println("The implementation class name of ResultSet Interface is : " + resultSet.getClass().getName());
			System.out.println();
			System.out.println("PID\tPNAME\tTEAM");
			//Step 4: Process the ResultSet
			while(resultSet.next())
			{
				Integer pid = resultSet.getInt(1);
				String pname = resultSet.getString(2);
				String team = resultSet.getString(3);

				System.out.println(pid + "\t" + pname + "\t" + team);
			}
		}
		//Step 5: Handle the Exceptions 
		catch (ClassNotFoundException ce)
		{
			ce.printStackTrace();
		}
		catch(SQLException se)
		{
			se.printStackTrace();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		//Step 6: Close the Connection
		finally
		{
			if(connection!=null)
			{
				try
				{
					connection.close();
					System.out.println("\nConnection Closed");
				}
				catch (SQLException se)
				{
					se.printStackTrace();
				}
			}
		}

	}
}
